import torch
import torch.nn as nn
import torchvision.transforms as transforms
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader
from torchvision.models import resnet18

# Define a simple LSTM layer to be integrated with CNN
class LSTMClassifier(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, num_classes):
        super(LSTMClassifier, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        # Initialize hidden and cell states
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)

        # Forward propagate LSTM
        out, _ = self.lstm(x, (h0, c0))
        # Decode the hidden state of the last time step
        out = self.fc(out[:, -1, :])
        return out

# Transform for spectrograms
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]), # Normalization for pre-trained models
])

# Dataset (using mock spectrograms)
dataset = ImageFolder("Spectrograms_Mock", transform=transform)
dataloader = DataLoader(dataset, batch_size=16, shuffle=True)

# CNN Model (pre-trained ResNet)
cnn_model = resnet18(pretrained=True)
num_ftrs = cnn_model.fc.in_features
cnn_model.fc = nn.Identity() # Remove the final classification layer

# Integrate CNN with LSTM
class CNNLSTM(nn.Module):
    def __init__(self, num_classes):
        super(CNNLSTM, self).__init__()
        self.cnn = cnn_model
        # Adjust input_size for LSTM based on CNN output features
        # Assuming CNN output is flattened to 1D vector for each image
        # For ResNet18, the output features before the final FC layer is 512
        self.lstm_classifier = LSTMClassifier(input_size=num_ftrs, hidden_size=128, num_layers=1, num_classes=num_classes)

    def forward(self, x):
        # CNN feature extraction
        cnn_features = self.cnn(x)
        # Reshape for LSTM: (batch_size, sequence_length, input_size)
        # Here, sequence_length is 1 as we are processing one image at a time
        lstm_input = cnn_features.unsqueeze(1) 
        output = self.lstm_classifier(lstm_input)
        return output

# Instantiate the combined model
model = CNNLSTM(num_classes=len(dataset.classes))

# Training loop (simplified for demonstration)
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

# Check if GPU is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

print(f"Using device: {device}")

for epoch in range(5):
    for i, (images, labels) in enumerate(dataloader):
        images = images.to(device)
        labels = labels.to(device)

        # Forward pass
        outputs = model(images)
        loss = criterion(outputs, labels)

        # Backward and optimize
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        if (i+1) % 10 == 0:
            print (f'Epoch [{epoch+1}/5], Step [{i+1}/{len(dataloader)}], Loss: {loss.item():.4f}')

print("Training complete.")


