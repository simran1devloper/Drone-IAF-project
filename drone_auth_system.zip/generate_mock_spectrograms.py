import numpy as np
import matplotlib.pyplot as plt
import os

def generate_mock_spectrogram(output_path, width=128, height=128):
    # Generate random data for a mock spectrogram
    mock_data = np.random.rand(height, width)

    plt.figure(figsize=(width/100, height/100), dpi=100)
    plt.imshow(mock_data, cmap='viridis', origin='lower')
    plt.axis('off')
    plt.tight_layout(pad=0)
    plt.savefig(output_path, bbox_inches='tight', pad_inches=0)
    plt.close()

def generate_mock_spectrograms_for_classes(num_classes=3, samples_per_class=10, output_dir='Spectrograms_Mock'):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for class_idx in range(num_classes):
        class_name = f'drone_type_{class_idx}'
        class_dir = os.path.join(output_dir, class_name)
        if not os.path.exists(class_dir):
            os.makedirs(class_dir)

        for i in range(samples_per_class):
            output_file = os.path.join(class_dir, f'mock_spectrogram_{class_idx}_{i}.png')
            generate_mock_spectrogram(output_file)
            print(f'Generated: {output_file}')

if __name__ == '__main__':
    generate_mock_spectrograms_for_classes()


