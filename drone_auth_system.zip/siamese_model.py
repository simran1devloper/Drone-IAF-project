import torch
import torch.nn as nn
import torchvision.transforms as transforms
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader
import torch.nn.functional as F
import numpy as np

class SiameseNetwork(nn.Module):
    def __init__(self):
        super(SiameseNetwork, self).__init__()
        self.cnn = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=5), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, kernel_size=5), nn.ReLU(), nn.MaxPool2d(2)
        )
        # Calculate the output size of the CNN to determine the input size for the FC layer
        # Assuming input image size is 224x224 after transform
        # ( (224 - 5 + 0)/1 + 1 ) / 2 = 110
        # ( (110 - 5 + 0)/1 + 1 ) / 2 = 53
        self.fc = nn.Sequential(
            nn.Linear(64 * 53 * 53, 256), nn.ReLU(),
            nn.Linear(256, 128)
        )

    def forward_once(self, x):
        out = self.cnn(x)
        out = out.view(out.size(0), -1)
        out = self.fc(out)
        return out

    def forward(self, input1, input2):
        out1 = self.forward_once(input1)
        out2 = self.forward_once(input2)
        return out1, out2

class ContrastiveLoss(nn.Module):
    def __init__(self, margin=1.0):
        super(ContrastiveLoss, self).__init__()
        self.margin = margin

    def forward(self, output1, output2, label):
        euclidean_distance = F.pairwise_distance(output1, output2)
        loss_contrastive = torch.mean((1 - label) * torch.pow(euclidean_distance, 2) +
                                      label * torch.pow(torch.clamp(self.margin - euclidean_distance, min=0.0), 2))
        return loss_contrastive

# Dataset and DataLoader for Siamese Network
# This requires a custom dataset that returns pairs of images and a label (0 for similar, 1 for dissimilar)
# For simplicity, we'll create a dummy dataset here.

class SiameseDataset(torch.utils.data.Dataset):
    def __init__(self, image_folder_path, transform=None):
        self.image_folder = ImageFolder(image_folder_path)
        self.transform = transform
        self.categories = self.image_folder.classes
        self.data = self.image_folder.imgs

    def __getitem__(self, index):
        img0_tuple = self.data[index]
        
        # We need to make sure pimg1_tuple is a different image but potentially from the same class
        # or a different class.
        should_get_same_class = np.random.randint(0, 2) # 0 for same, 1 for different

        if should_get_same_class:
            while True:
                img1_tuple = self.data[np.random.randint(0, len(self.data))]
                if img0_tuple[1] != img1_tuple[1]: # Check if different class
                    break
            label = 0.0 # Dissimilar
        else:
            img1_tuple = self.data[np.random.randint(0, len(self.data))]
            label = 1.0 # Similar

        img0 = self.image_folder.loader(img0_tuple[0])
        img1 = self.image_folder.loader(img1_tuple[0])

        if self.transform:
            img0 = self.transform(img0)
            img1 = self.transform(img1)

        return img0, img1, torch.from_numpy(np.array([label], dtype=np.float32))

    def __len__(self):
        return len(self.image_folder)

# Transform for spectrograms
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]), # Normalization for pre-trained models
])

# Dataset (using mock spectrograms)
siamese_dataset = SiameseDataset(image_folder_path="Spectrograms_Mock", transform=transform)
siamese_dataloader = DataLoader(siamese_dataset, batch_size=16, shuffle=True)

# Model
model = SiameseNetwork()

# Training loop (simplified)
criterion = ContrastiveLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

# Check if GPU is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

print(f"Using device: {device}")

for epoch in range(5):
    for i, (img1, img2, label) in enumerate(siamese_dataloader):
        img1, img2, label = img1.to(device), img2.to(device), label.to(device)

        optimizer.zero_grad()
        output1, output2 = model(img1, img2)
        loss = criterion(output1, output2, label)
        loss.backward()
        optimizer.step()

        if (i+1) % 10 == 0:
            print (f'Epoch [{epoch+1}/5], Step [{i+1}/{len(siamese_dataloader)}], Loss: {loss.item():.4f}')

print("Siamese network training complete.")


