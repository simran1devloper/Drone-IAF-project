import { useState } from 'react'
import { Upload, FileImage, BarChart3, History, Settings } from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import './App.css'

function App() {
  const [uploadedFile, setUploadedFile] = useState(null)
  const [prediction, setPrediction] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [history, setHistory] = useState([])

  const handleFileUpload = async (event) => {
    const file = event.target.files[0]
    if (!file) return

    setUploadedFile(file)
    setIsLoading(true)

    // Mock API call
    setTimeout(() => {
      const mockPrediction = {
        prediction: ['drone_type_0', 'drone_type_1', 'drone_type_2'][Math.floor(Math.random() * 3)],
        confidence: (Math.random() * 0.3 + 0.7).toFixed(3),
        status: 'success'
      }
      setPrediction(mockPrediction)
      setHistory(prev => [...prev, {
        id: Date.now(),
        filename: file.name,
        ...mockPrediction,
        timestamp: new Date().toLocaleString()
      }])
      setIsLoading(false)
    }, 2000)
  }

  const getStatusBadge = (prediction) => {
    const isAuthorized = prediction?.confidence > 0.7
    return (
      <Badge variant={isAuthorized ? "default" : "destructive"}>
        {isAuthorized ? "Authorized" : "Unauthorized"}
      </Badge>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Drone Authentication System
          </h1>
          <p className="text-lg text-gray-600">
            RF Signal Spectrogram Analysis for Drone Identification
          </p>
        </header>

        <Tabs defaultValue="upload" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="upload" className="flex items-center gap-2">
              <Upload className="w-4 h-4" />
              Upload
            </TabsTrigger>
            <TabsTrigger value="compare" className="flex items-center gap-2">
              <FileImage className="w-4 h-4" />
              Compare
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <History className="w-4 h-4" />
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Upload Spectrogram</CardTitle>
                <CardDescription>
                  Upload a drone RF signal spectrogram for authentication
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid w-full max-w-sm items-center gap-1.5">
                  <Label htmlFor="spectrogram">Spectrogram Image</Label>
                  <Input
                    id="spectrogram"
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    disabled={isLoading}
                  />
                </div>

                {uploadedFile && (
                  <div className="mt-4">
                    <p className="text-sm text-gray-600 mb-2">Uploaded: {uploadedFile.name}</p>
                    <img
                      src={URL.createObjectURL(uploadedFile)}
                      alt="Uploaded spectrogram"
                      className="max-w-xs rounded-lg border"
                    />
                  </div>
                )}

                {isLoading && (
                  <div className="flex items-center justify-center p-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                    <span className="ml-2">Analyzing spectrogram...</span>
                  </div>
                )}

                {prediction && !isLoading && (
                  <Card className="mt-4">
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        Authentication Result
                        {getStatusBadge(prediction)}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <p><strong>Drone Type:</strong> {prediction.prediction}</p>
                        <p><strong>Confidence:</strong> {(prediction.confidence * 100).toFixed(1)}%</p>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ width: `${prediction.confidence * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="compare" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Compare Spectrograms</CardTitle>
                <CardDescription>
                  Compare two drone spectrograms using Siamese network
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="spectrogram1">First Spectrogram</Label>
                    <Input id="spectrogram1" type="file" accept="image/*" />
                  </div>
                  <div>
                    <Label htmlFor="spectrogram2">Second Spectrogram</Label>
                    <Input id="spectrogram2" type="file" accept="image/*" />
                  </div>
                </div>
                <Button className="mt-4 w-full">Compare Spectrograms</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Total Authentications</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-blue-600">{history.length}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Authorized</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-green-600">
                    {history.filter(h => h.confidence > 0.7).length}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Unauthorized</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-red-600">
                    {history.filter(h => h.confidence <= 0.7).length}
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Authentication History</CardTitle>
                <CardDescription>
                  Recent drone authentication attempts
                </CardDescription>
              </CardHeader>
              <CardContent>
                {history.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No authentication history yet</p>
                ) : (
                  <div className="space-y-4">
                    {history.slice().reverse().map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <p className="font-medium">{item.filename}</p>
                          <p className="text-sm text-gray-600">{item.timestamp}</p>
                          <p className="text-sm">Type: {item.prediction} | Confidence: {(item.confidence * 100).toFixed(1)}%</p>
                        </div>
                        {getStatusBadge(item)}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App

