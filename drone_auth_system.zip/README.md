# Drone Authentication System - README

## Project Overview

The Drone Authentication System is a comprehensive AI-based solution for identifying and authenticating unmanned aerial vehicles (UAVs) through RF signal spectrogram analysis. The system combines deep learning techniques with modern web technologies to provide real-time drone authentication capabilities.

## Features

- **RF Signal Analysis**: Convert RF signals to spectrograms for visual analysis
- **Deep Learning Classification**: CNN-LSTM hybrid model for drone type identification
- **Siamese Network Comparison**: Compare unknown drones against authorized signatures
- **Web-based Interface**: Responsive React frontend with intuitive user experience
- **REST API**: Comprehensive Flask-based backend with full API documentation
- **Real-time Processing**: Mock implementation demonstrating real-time capabilities
- **Historical Analytics**: Track and analyze authentication history
- **Scalable Architecture**: Modular design supporting various deployment scenarios

## Technology Stack

### Backend
- **Python 3.11**
- **Flask 3.1.1** - Web framework
- **PyTorch 2.7.1** - Deep learning framework
- **NumPy & SciPy** - Scientific computing
- **Matplotlib** - Visualization
- **Flask-CORS** - Cross-origin resource sharing

### Frontend
- **React 18.3.1** - UI framework
- **Vite 6.3.5** - Build tool
- **Tailwind CSS** - Styling framework
- **shadcn/ui** - Component library
- **Lucide Icons** - Icon library

## Installation and Setup

### Prerequisites
- Python 3.11+
- Node.js 20+
- npm or pnpm

### Backend Setup
```bash
cd drone_auth_backend
source venv/bin/activate
pip install -r requirements.txt
python src/main.py
```

### Frontend Setup
```bash
cd drone_auth_frontend
npm install
npm run dev --host
```

## API Endpoints

### Authentication
- `POST /api/upload` - Upload spectrogram for classification
- `POST /api/predict` - Classify base64-encoded spectrogram
- `POST /api/compare` - Compare two spectrograms

### System Management
- `GET /api/status` - System health information
- `GET /api/history` - Authentication history
- `POST /api/train` - Model training interface

## Usage

1. **Upload Spectrogram**: Navigate to the Upload tab and select a spectrogram image
2. **View Results**: The system will display drone type classification and confidence score
3. **Compare Drones**: Use the Compare tab to analyze similarity between two spectrograms
4. **Monitor Analytics**: View system statistics and authentication trends
5. **Review History**: Access detailed logs of all authentication attempts

## Architecture

The system follows a three-tier architecture:

- **Presentation Tier**: React web application
- **Application Tier**: Flask REST API
- **Data Tier**: Deep learning models and data processing

## Model Architecture

### CNN-LSTM Classifier
- **Input**: 224x224 RGB spectrogram images
- **CNN Backbone**: ResNet-18 (pre-trained)
- **LSTM Component**: Temporal sequence modeling
- **Output**: Drone type probabilities

### Siamese Network
- **Purpose**: Similarity comparison between drone signatures
- **Architecture**: Dual CNN branches with shared weights
- **Loss Function**: Contrastive loss
- **Output**: Similarity scores

## Deployment

### Development
```bash
# Backend
cd drone_auth_backend && source venv/bin/activate && python src/main.py

# Frontend
cd drone_auth_frontend && npm run dev --host
```

### Production
The system supports Docker containerization and can be deployed on various platforms including cloud services and edge devices.

## Testing

The system includes comprehensive testing for:
- API endpoint functionality
- User interface responsiveness
- Model integration
- Error handling
- Performance validation

## Future Enhancements

- Real RF signal data integration
- Real-time streaming capabilities
- Advanced model architectures (Transformers, Attention mechanisms)
- Edge computing deployment
- Multi-sensor fusion
- Enhanced security features

## Contributing

1. Fork the repository
2. Create a feature branch
3. Implement changes with tests
4. Submit a pull request

## License

This project is developed for educational and research purposes. Please ensure compliance with local regulations regarding RF signal analysis and drone detection.

## Support

For questions, issues, or contributions, please refer to the project documentation or contact the development team.

## Acknowledgments

This project demonstrates the integration of modern AI techniques with practical web application development, showcasing the potential for RF-based drone authentication in security and airspace management applications.

